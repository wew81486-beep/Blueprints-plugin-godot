@tool
extends VBoxContainer

const FLOW := Color(0.35, 0.85, 0.55)
const DATA := Color(0.35, 0.65, 1.0)

var graph: GraphEdit
var code_view: TextEdit
var search: LineEdit
var palette: OptionButton
var file_dialog: FileDialog
var status_label: Label
var next_id := 1
var generated := ""
var current_script_name := "blueprint_generated.gd"

var node_types := [
	"Evento: Ready", "Evento: Input", "Imprimir", "Llamar método",
	"Obtener propiedad", "Establecer propiedad", "Si / Si no",
	"Bucle For", "Bucle While", "Esperar", "Variable",
	"Retornar", "Emitir señal", "Liberar nodo", "Comentario"
]

func _ready() -> void:
	name = "Blueprints"
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	_build_ui()

func _build_ui() -> void:
	var top := HBoxContainer.new()
	add_child(top)
	var title := Label.new()
	title.text = "BLUEPRINT STUDIO"
	title.add_theme_font_size_override("font_size", 19)
	top.add_child(title)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(spacer)
	var generate := Button.new()
	generate.text = "Generar GDScript"
	generate.pressed.connect(generate_code)
	top.add_child(generate)
	var save := Button.new()
	save.text = "Guardar .gd"
	save.pressed.connect(save_code)
	top.add_child(save)

	var split := HSplitContainer.new()
	split.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(split)

	var left := VBoxContainer.new()
	left.custom_minimum_size.x = 205
	split.add_child(left)
	var palette_title := Label.new()
	palette_title.text = "NODOS"
	palette_title.add_theme_font_size_override("font_size", 15)
	left.add_child(palette_title)
	search = LineEdit.new()
	search.placeholder_text = "Buscar nodo..."
	search.text_changed.connect(_refresh_palette)
	left.add_child(search)
	palette = OptionButton.new()
	palette.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_child(palette)
	var add := Button.new()
	add.text = "＋ Añadir al gráfico"
	add.pressed.connect(_add_selected_node)
	left.add_child(add)
	var hint := Label.new()
	hint.text = "Verde: ejecución\nAzul: datos\n\nLlamar método permite usar métodos de cualquier clase/objeto de Godot escribiendo su ruta y nombre."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_color_override("font_color", Color(0.7,0.7,0.7))
	left.add_child(hint)

	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.size_flags_vertical = Control.SIZE_EXPAND_FILL
	split.add_child(right)

	graph = GraphEdit.new()
	graph.size_flags_vertical = Control.SIZE_EXPAND_FILL
	graph.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	graph.minimap_enabled = true
	graph.show_grid = true
	graph.snapping_enabled = true
	graph.snapping_distance = 20
	graph.add_valid_connection_type(0, 0)
	graph.add_valid_connection_type(1, 1)
	graph.connection_request.connect(_on_connection_request)
	graph.disconnection_request.connect(_on_disconnection_request)
	right.add_child(graph)

	status_label = Label.new()
	status_label.text = "Arrastra conexiones entre los pines. Doble clic en el gráfico no es necesario: selecciona nodos desde la izquierda."
	right.add_child(status_label)

	var code_label := Label.new()
	code_label.text = "Vista previa de GDScript"
	right.add_child(code_label)
	code_view = TextEdit.new()
	code_view.custom_minimum_size.y = 180
	code_view.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	code_view.placeholder_text = "Pulsa Generar GDScript..."
	code_view.syntax_highlighter = CodeHighlighter.new()
	for word in ["func","var","if","else","for","while","return","await","extends"]:
		code_view.syntax_highlighter.add_keyword_color(word, Color(0.8,0.65,1.0))
	right.add_child(code_view)

	file_dialog = FileDialog.new()
	file_dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE
	file_dialog.access = FileDialog.ACCESS_RESOURCES
	file_dialog.filters = PackedStringArray(["*.gd ; GDScript"])
	file_dialog.file_selected.connect(_on_file_selected)
	add_child(file_dialog)

	_refresh_palette("")
	_add_node("Evento: Ready")

func _refresh_palette(filter: String) -> void:
	palette.clear()
	for t in node_types:
		if filter.is_empty() or t.to_lower().contains(filter.to_lower()):
			palette.add_item(t)

func _add_selected_node() -> void:
	if palette.item_count == 0:
		return
	_add_node(palette.get_item_text(palette.selected))

func _add_node(kind: String) -> void:
	var pos := Vector2(80 + (graph.get_child_count() % 3) * 230, 80 + int(graph.get_child_count() / 3) * 150)
	var n := GraphNode.new()
	n.name = "BP_%d" % next_id
	n.title = kind
	n.position_offset = pos
	n.custom_minimum_size = Vector2(220, 100)
	n.resizable = true
	n.set_meta("kind", kind)
	n.set_meta("id", next_id)
	graph.add_child(n)
	next_id += 1

	match kind:
		"Evento: Ready":
			_add_control_row(n, _label("Se ejecuta al iniciar"), -1, 0)
		"Evento: Input":
			_add_control_row(n, _label("Lee eventos de entrada"), -1, 0)
		"Imprimir":
			var e := _line("Text", "Hola desde Blueprints")
			_add_control_row(n, e, 0, 0)
		"Llamar método":
			var target := _line("Target", "self")
			var method := _line("Method", "queue_redraw")
			var args := _line("Arguments", "")
			_add_control_row(n, target, 0, -1)
			_add_control_row(n, method, -1, -1)
			_add_control_row(n, args, -1, 0)
		"Obtener propiedad":
			_add_control_row(n, _line("Target", "self"), -1, -1)
			_add_control_row(n, _line("Property", "position"), -1, -1)
			_add_control_row(n, _label("Salida: valor"), -1, -1, DATA, DATA)
		"Establecer propiedad":
			_add_control_row(n, _line("Target", "self"), 0, -1)
			_add_control_row(n, _line("Property", "visible"), -1, -1)
			_add_control_row(n, _line("Value", "true"), -1, 0)
		"Si / Si no":
			_add_control_row(n, _line("Condition", "true"), 0, -1)
			_add_control_row(n, _label("VERDADERO"), -1, 0)
			_add_control_row(n, _label("FALSO"), -1, 0)
		"Bucle For":
			_add_control_row(n, _line("Variable", "i"), 0, -1)
			_add_control_row(n, _spin("Start", 0, -100000, 100000), -1, -1)
			_add_control_row(n, _spin("End", 5, -100000, 100000), -1, 0)
		"Bucle While":
			_add_control_row(n, _line("Condition", "false"), 0, 0)
		"Esperar":
			_add_control_row(n, _spin("Seconds", 1, 0, 3600, 0.1), 0, 0)
		"Variable":
			_add_control_row(n, _line("Name", "my_value"), 0, 0)
			_add_control_row(n, _line("Value", "0"), -1, -1)
		"Retornar":
			_add_control_row(n, _line("Value (optional)", ""), 0, -1)
		"Emitir señal":
			_add_control_row(n, _line("Target", "self"), 0, -1)
			_add_control_row(n, _line("Signal", "my_signal"), -1, 0)
		"Liberar nodo":
			_add_control_row(n, _line("Target", "self"), 0, 0)
		"Comentario":
			var note := TextEdit.new()
			note.name = "Comment"
			note.text = "Escribe una nota..."
			note.custom_minimum_size.y = 65
			_add_control_row(n, note, -1, -1)

func _label(text: String) -> Label:
	var l := Label.new()
	l.text = text
	return l

func _line(field_name: String, value: String) -> LineEdit:
	var e := LineEdit.new()
	e.name = field_name
	e.text = value
	e.placeholder_text = field_name
	return e

func _spin(field_name: String, value: float, minimum: float, maximum: float, step: float = 1.0) -> SpinBox:
	var s := SpinBox.new()
	s.name = field_name
	s.min_value = minimum
	s.max_value = maximum
	s.step = step
	s.value = value
	return s

func _add_control_row(n: GraphNode, control: Control, left_type: int, right_type: int, left_color: Color = FLOW, right_color: Color = FLOW) -> void:
	n.add_child(control)
	var row := n.get_child_count() - 1
	n.set_slot(row, left_type >= 0, left_type, left_color, right_type >= 0, right_type, right_color)

func _on_connection_request(from_node: StringName, from_port: int, to_node: StringName, to_port: int) -> void:
	if from_node == to_node:
		status_label.text = "No conectes un nodo consigo mismo."
		return
	if not graph.is_node_connected(from_node, from_port, to_node, to_port):
		graph.connect_node(from_node, from_port, to_node, to_port)

func _on_disconnection_request(from_node: StringName, from_port: int, to_node: StringName, to_port: int) -> void:
	graph.disconnect_node(from_node, from_port, to_node, to_port)

func _get_node(node_name: String) -> GraphNode:
	return graph.get_node_or_null(NodePath(node_name)) as GraphNode

func _get_field(n: GraphNode, field_name: String) -> Node:
	return n.find_child(field_name, true, false)

func _next(node_name: String, port: int = 0) -> String:
	for c in graph.get_connection_list():
		if str(c["from_node"]) == node_name and int(c["from_port"]) == port:
			return str(c["to_node"])
	return ""

func _connections_to(node_name: String) -> Array:
	var result := []
	for c in graph.get_connection_list():
		if str(c["to_node"]) == node_name:
			result.append(c)
	return result

func _safe_name(value: String) -> String:
	var s := value.strip_edges().replace(" ", "_")
	return s if s.is_valid_identifier() else "my_value"

func _quote(value: String) -> String:
	return var_to_str(value)

func generate_code() -> void:
	var events: Array[GraphNode] = []
	for child in graph.get_children():
		if child is GraphNode and str(child.get_meta("kind", "")) == "Evento: Ready":
			events.append(child)
	var lines := PackedStringArray(["extends Node", ""])
	var declarations := {}
	for child in graph.get_children():
		if child is GraphNode and str(child.get_meta("kind", "")) == "Variable":
			var nm := _get_field(child, "Name") as LineEdit
			var val := _get_field(child, "Value") as LineEdit
			var key := _safe_name("my_value" if nm == null else nm.text)
			declarations[key] = "0" if val == null else val.text
	for key in declarations:
		lines.append("var %s = %s" % [key, declarations[key]])
	if not declarations.is_empty():
		lines.append("")
	if events.is_empty():
		lines.append("# Añade un nodo Evento: Ready para generar _ready().")
	else:
		lines.append("func _ready() -> void:")
		var visited := {}
		var body := _emit_chain(str(events[0].name), 0, 1, visited)
		if body.is_empty():
			lines.append("\tpass")
		else:
			lines.append_array(body)
	# Input event handler is generated when an Input event node exists.
	for child in graph.get_children():
		if child is GraphNode and str(child.get_meta("kind", "")) == "Evento: Input":
			lines.append("")
			lines.append("func _input(event: InputEvent) -> void:")
			var body_input := _emit_chain(str(child.name), 0, 1, {})
			if body_input.is_empty():
				lines.append("\tpass")
			else:
				lines.append_array(body_input)
			break
	generated = "\n".join(lines)
	code_view.text = generated
	status_label.text = "Código generado. Los métodos se invocan mediante el nodo genérico «Llamar método»."

func _emit_chain(start: String, port: int, indent: int, visited: Dictionary) -> PackedStringArray:
	var out := PackedStringArray()
	var current := _next(start, port)
	var count := 0
	while current != "" and count < 300:
		if visited.has(current):
			out.append("\t".repeat(indent) + "# Ciclo detectado; se detuvo la rama.")
			break
		visited[current] = true
		var n := _get_node(current)
		if n == null:
			break
		var kind := str(n.get_meta("kind", ""))
		var p := "\t".repeat(indent)
		match kind:
			"Imprimir":
				var e := _get_field(n, "Text") as LineEdit
				out.append(p + "print(%s)" % _quote("Hola" if e == null else e.text))
			"Llamar método":
				var t := _get_field(n, "Target") as LineEdit
				var m := _get_field(n, "Method") as LineEdit
				var a := _get_field(n, "Arguments") as LineEdit
				var target := "self" if t == null or t.text.strip_edges().is_empty() else t.text.strip_edges()
				var method := "queue_redraw" if m == null else _safe_name(m.text)
				var args := "" if a == null else a.text.strip_edges()
				out.append(p + "%s.%s(%s)" % [target, method, args])
			"Establecer propiedad":
				var t2 := _get_field(n, "Target") as LineEdit
				var prop := _get_field(n, "Property") as LineEdit
				var value := _get_field(n, "Value") as LineEdit
				var target2 := "self" if t2 == null else t2.text
				var property := "visible" if prop == null else _safe_name(prop.text)
				var val := "true" if value == null else value.text
				out.append(p + "%s.%s = %s" % [target2, property, val])
			"Si / Si no":
				var cond := _get_field(n, "Condition") as LineEdit
				out.append(p + "if %s:" % ("true" if cond == null else cond.text))
				var yes := _emit_chain(current, 0, indent + 1, visited.duplicate())
				out.append_array(yes if not yes.is_empty() else PackedStringArray([p + "\tpass"]))
				out.append(p + "else:")
				var no := _emit_chain(current, 1, indent + 1, visited.duplicate())
				out.append_array(no if not no.is_empty() else PackedStringArray([p + "\tpass"]))
				break
			"Bucle For":
				var vn := _get_field(n, "Variable") as LineEdit
				var st := _get_field(n, "Start") as SpinBox
				var en := _get_field(n, "End") as SpinBox
				var vname := _safe_name("i" if vn == null else vn.text)
				var start_value := int(0 if st == null else st.value)
				var end_value := int(5 if en == null else en.value)
				out.append(p + "for %s in range(%d, %d):" % [vname, start_value, end_value])
				var loop_body := _emit_chain(current, 0, indent + 1, visited.duplicate())
				out.append_array(loop_body if not loop_body.is_empty() else PackedStringArray([p + "\tpass"]))
				break
			"Bucle While":
				var condition := _get_field(n, "Condition") as LineEdit
				out.append(p + "while %s:" % ("false" if condition == null else condition.text))
				var while_body := _emit_chain(current, 0, indent + 1, visited.duplicate())
				out.append_array(while_body if not while_body.is_empty() else PackedStringArray([p + "\tpass"]))
				break
			"Esperar":
				var seconds := _get_field(n, "Seconds") as SpinBox
				out.append(p + "await get_tree().create_timer(%s).timeout" % str(1.0 if seconds == null else seconds.value))
			"Retornar":
				var rv := _get_field(n, "Value (optional)") as LineEdit
				out.append(p + "return" if rv == null or rv.text.strip_edges().is_empty() else p + "return " + rv.text)
			"Emitir señal":
				var target3 := _get_field(n, "Target") as LineEdit
				var sig := _get_field(n, "Signal") as LineEdit
				out.append(p + "%s.%s.emit()" % ["self" if target3 == null else target3.text, "my_signal" if sig == null else _safe_name(sig.text)])
			"Liberar nodo":
				var target4 := _get_field(n, "Target") as LineEdit
				out.append(p + "%s.queue_free()" % ("self" if target4 == null else target4.text))
			"Comentario":
				var note := _get_field(n, "Comment") as TextEdit
				var txt := "Nota" if note == null else note.text
				for part in txt.split("\n"):
					out.append(p + "# " + part)
			_:
				out.append(p + "# Evento o nodo sin generador de código específico")
		current = _next(current, 0)
		count += 1
	if count >= 300:
		out.append("\t".repeat(indent) + "# Límite de seguridad de 300 nodos alcanzado.")
	return out

func save_code() -> void:
	if generated.is_empty():
		generate_code()
	file_dialog.current_file = current_script_name
	file_dialog.popup_centered_ratio(0.7)

func _on_file_selected(path: String) -> void:
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		status_label.text = "No se pudo guardar el archivo."
		return
	f.store_string(code_view.text)
	f.close()
	status_label.text = "Guardado: " + path

func get_editor_state() -> Dictionary:
	return {"next_id": next_id}

func set_editor_state(state: Dictionary) -> void:
	next_id = int(state.get("next_id", next_id))
