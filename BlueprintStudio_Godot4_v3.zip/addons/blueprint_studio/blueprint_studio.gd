@tool
extends EditorPlugin

const BLUEPRINT_SCREEN = preload("res://addons/blueprint_studio/blueprint_screen.gd")
var screen: Control

func _enter_tree() -> void:
	screen = BLUEPRINT_SCREEN.new()
	EditorInterface.get_editor_main_screen().add_child(screen)
	screen.hide()

func _exit_tree() -> void:
	if is_instance_valid(screen):
		screen.queue_free()

func _has_main_screen() -> bool:
	return true

func _get_plugin_name() -> String:
	return "Blueprints"

func _get_plugin_icon() -> Texture2D:
	return EditorInterface.get_editor_theme().get_icon("GraphEdit", "EditorIcons")

func _make_visible(visible: bool) -> void:
	if is_instance_valid(screen):
		screen.visible = visible

func _get_state() -> Dictionary:
	if is_instance_valid(screen):
		return screen.get_editor_state()
	return {}

func _set_state(state: Dictionary) -> void:
	if is_instance_valid(screen):
		screen.set_editor_state(state)

func _get_unsaved_status(_for_scene: String) -> String:
	return ""
