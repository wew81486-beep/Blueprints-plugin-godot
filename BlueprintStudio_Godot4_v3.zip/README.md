# Blueprint Studio 3.0 — Godot 4

Esta versión añade una pantalla principal llamada **Blueprints**, junto a 2D, 3D y Script.

## Instalar
1. Descomprime el ZIP.
2. Copia `addons/blueprint_studio` dentro de tu proyecto Godot.
3. En Godot abre Proyecto > Ajustes del proyecto > Plugins.
4. Activa el plugin **Blueprints**.
5. Aparecerá una pestaña **Blueprints** en la barra principal del editor.

## Nodos
Evento Ready, Evento Input, Imprimir, Llamar método, Obtener propiedad (visual), Establecer propiedad, Si/Si no, Bucle For, Bucle While, Esperar, Variable, Retornar, Emitir señal, Liberar nodo y Comentario.

## Usar cualquier método de Godot
El nodo **Llamar método** permite escribir:
- Target: `self`, `$Sprite2D`, `$Player`, `get_node("Player")`
- Method: nombre del método, por ejemplo `queue_redraw`, `play`, `show`, `hide`, `add_child`
- Arguments: argumentos GDScript separados por coma, por ejemplo `"Hola"` o `Vector2(10, 20)`

Así puedes llamar métodos de las clases y nodos de Godot aunque no exista un bloque dedicado para cada método.

## Importante: alcance
Godot tiene miles de métodos, propiedades y señales entre sus clases integradas y clases propias. No es práctico ni correcto prometer un bloque visual preconstruido para cada función. Esta versión ofrece un nodo genérico de llamada a método para invocar APIs de Godot y bloques comunes de flujo. El nodo Obtener propiedad está presente como elemento visual, pero todavía no participa en la generación de expresiones conectadas.

La generación actual cubre flujos básicos y no reemplaza todas las capacidades de GDScript: tipado avanzado, lambdas, anotaciones, clases internas, recursos complejos y conexiones de datos completas necesitan implementaciones adicionales. Revisa el código generado antes de usarlo en un proyecto importante.

Requiere Godot 4.x.
